# Mapping engine

Mappings address source columns by zero-based position plus their display header. Supported target strategies are direct field, constant, value map, resolver lookup, safe template, transform chain, structured-description contribution, and ignore.

Templates accept fixed text and explicit column placeholders only. No `eval`, PHP, or JavaScript is allowed. Transformations are allowlisted and typed. Conditions are data-only expressions (`equals`, `not_equals`, `contains`, `starts_with`, `ends_with`, controlled `regex`, `empty`, `not_empty`).

The target registry exposes stable functional concepts, not SQL columns. Each target declares its value type, cardinality, creation phase, resolver, compatible transformations, and dependencies. `Entity from resolved Location` is modeled as a dependency rather than a second source mapping.

The first mapping UI persists one explicit decision for every positional source column: direct functional target or ignore. External ticket identifier and title are mandatory before the profile reaches `mapping_configured`. A target may only be selected once in this initial direct-mapping stage. Value maps, resolvers, transforms, structured descriptions, and repeated timeline contributions build on these persisted decisions in subsequent stages.

Controlled fields then use streaming distinct-value discovery. Status, type, priority, urgency, and impact are mapped to GLPI 11 constants. Users, groups, entities, locations, and ITIL categories use exact or normalized-exact lookup against GLPI objects. A unique exact suggestion is preselected, but remains unvalidated until the operator saves the form. The official GLPI AJAX dropdowns provide permission-aware manual search without materializing complete reference tables in the page. Unknown values must be ignored explicitly or remain blocking; the plugin never creates users automatically.

Requester, assigned-technician, requester-group, and technician-group source fields may contain multiple actors. Their separator is stored with the field mapping and applied identically by distinct-value discovery and `MigrationPlanBuilder`. Automatic mode recognizes semicolons, pipes, and line breaks; comma splitting requires an explicit choice to protect `Last name, First name` values. Each controlled field is bounded to 200 distinct values. For actor fields only, an explicit profile policy can omit the whole actor role and allow ticket import to continue without those actors; all omissions are reported as plan warnings.

Once value correspondence is complete, the same mapping data builds a read-only immutable plan for the first source row. This preview performs no GLPI business-object write and is the foundation shared by the upcoming pilot import and full dry run.

Structured description values are escaped before safe markup is generated. The main description column is identified explicitly and rendered in its own section. A profile may include mapped fields, unmapped fields, or both in a historical-data section, exclude sensitive or technical columns individually, and position metadata before or after the main description. Empty fields are always omitted and an HTML separator keeps both sections readable. A profile keeps all decisions so later delta files are interpreted identically.
